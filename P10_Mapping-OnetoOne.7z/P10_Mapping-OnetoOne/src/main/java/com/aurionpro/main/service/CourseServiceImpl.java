package com.aurionpro.main.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aurionpro.main.dto.CourseDto;
import com.aurionpro.main.dto.InstructorDto;
import com.aurionpro.main.entity.Course;
import com.aurionpro.main.entity.Instructor;
import com.aurionpro.main.repository.CourseRepository;

@Service
public class CourseServiceImpl implements CourseService  {

	@Autowired
	private CourseRepository courseRepo;
	
//	@Override
//	public CourseDto addNewCourse(CourseDto courseDto) {
//		
//		Course course = new Course();
//		
//		course.setDuration(courseDto.getDuration());
//		course.setFees(courseDto.getFees());
//		course.setName(courseDto.getName());
//		
//		course = courseRepo.save(course);
//		
//		courseDto.setCourseId(course.getCourseId());
//		courseDto.setDuration(course.getDuration());
//		courseDto.setFees(course.getFees());
//		courseDto.setName(course.getName());
//		
//		return courseDto;
//	}
	
	
	@Override
	public CourseDto addNewCourse(CourseDto courseDto) {
		
		Course course = courseMapper(courseDto);	
		course = courseRepo.save(course);
		courseDto = courseDtoMapper(course);
		
		return courseDto;
	}
	
	public Course courseMapper(CourseDto courseDto)
	{
        Course course = new Course();
		
		course.setDuration(courseDto.getDuration());
		course.setFees(courseDto.getFees());
		course.setName(courseDto.getName());
		
		return course;
	}
	
	public CourseDto courseDtoMapper(Course course)
	{
		CourseDto courseDto = new CourseDto();
		
		courseDto.setCourseId(course.getCourseId());
		courseDto.setDuration(course.getDuration());
		courseDto.setFees(course.getFees());
		courseDto.setName(course.getName());
		
		return courseDto;		
	}

	@Override
	public List<CourseDto> getAllCourse() {
		
		List<Course> courses = courseRepo.findAll();
		List<CourseDto> courseDtos= new ArrayList<>();
		
		for(Course i : courses)
		{
			CourseDto	courseDto = courseDtoMapper(i);
			
			courseDtos.add(courseDto);		
		}
		
		return courseDtos;
	}

	@Override
	public CourseDto getCourseDtoById(int id) {

      Optional<Course> optionalcourse = courseRepo.findById(id);
		
		if(optionalcourse.isEmpty())
		 return null;
		
		Course course = optionalcourse.get();
		
	//	InstructorDto	instructorDto = maptoInstructorDto(instructor);
		
		return courseDtoMapper(course);
	}

}
