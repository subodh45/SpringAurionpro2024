package com.aurionpro.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aurionpro.main.dto.CourseDto;
import com.aurionpro.main.dto.InstructorDto;
import com.aurionpro.main.entity.Course;
import com.aurionpro.main.service.CourseService;

@RestController
@RequestMapping("/advancemappingapp")
public class CourseController {

	@Autowired
	private CourseService courseService;
	
	
	
	@PostMapping("/courses")
	public ResponseEntity<CourseDto> addNewCorseDto(@RequestBody CourseDto courseDto)
	{
		return ResponseEntity.ok(courseService.addNewCourse(courseDto));
	}
	
	@GetMapping("/courses")
	public ResponseEntity<List<CourseDto>> getAllCourseDto()
	{
		return ResponseEntity.ok(courseService.getAllCourse());
	}
	
	@GetMapping("/courses/{id}")
	public ResponseEntity<CourseDto> getCourseDtobyId(@PathVariable int id)
	{
		return ResponseEntity.ok(courseService.getCourseDtoById(id));
	}
}

