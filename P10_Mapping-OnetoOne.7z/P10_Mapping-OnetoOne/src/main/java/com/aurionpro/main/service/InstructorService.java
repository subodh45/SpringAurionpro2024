package com.aurionpro.main.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.aurionpro.main.dto.InstructorDto;

public interface InstructorService {

	InstructorDto addInstructor(InstructorDto instructorDto);
	
	List<InstructorDto> getAllInstructor();
	
	InstructorDto getInstructorDtoById(int id);
	
	
}
