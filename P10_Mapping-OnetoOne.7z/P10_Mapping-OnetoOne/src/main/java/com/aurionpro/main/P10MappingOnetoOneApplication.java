package com.aurionpro.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P10MappingOnetoOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(P10MappingOnetoOneApplication.class, args);
	}
}
