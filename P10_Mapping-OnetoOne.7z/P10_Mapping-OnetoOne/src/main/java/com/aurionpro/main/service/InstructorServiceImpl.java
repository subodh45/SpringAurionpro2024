package com.aurionpro.main.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aurionpro.main.dto.InstructorDto;
import com.aurionpro.main.entity.Instructor;
import com.aurionpro.main.repository.InstructorRepository;

@Service
public class InstructorServiceImpl implements InstructorService{

	@Autowired
	private InstructorRepository instructorRepo;
	
	@Override
	public InstructorDto addInstructor(InstructorDto instructorDto) {
		
		Instructor instructor = new Instructor();
		
		instructor.setEmail(instructorDto.getEmail());
		instructor.setName(instructorDto.getName());
		instructor.setQualification(instructorDto.getQualification());
		
		instructor = instructorRepo.save(instructor);
		
		instructorDto.setEmail(instructor.getEmail());
		instructorDto.setInstructorId(instructor.getInstructorId());
		instructorDto.setName(instructor.getName());
		instructorDto.setQualification(instructor.getQualification());
		
		return instructorDto;
	}
	
	
	public Instructor maptoInstructor(InstructorDto instructorDto)
	{
        Instructor instructor = new Instructor();
		
		instructor.setEmail(instructorDto.getEmail());
		instructor.setName(instructorDto.getName());
		instructor.setQualification(instructorDto.getQualification());
		
		return instructor;
	}
	
	public InstructorDto maptoInstructorDto(Instructor instructor)
	{
		 InstructorDto  instructorDto = new  InstructorDto();
		
		instructorDto.setEmail(instructor.getEmail());
		instructorDto.setInstructorId(instructor.getInstructorId());
		instructorDto.setName(instructor.getName());
		instructorDto.setQualification(instructor.getQualification());
		
		return instructorDto;
	}
	

	@Override
	public List<InstructorDto> getAllInstructor() {
		
		List<Instructor> instructors = instructorRepo.findAll();
		List<InstructorDto> instructorDtos= new ArrayList<>();
		
		for(Instructor i : instructors)
		{
			InstructorDto	instructorDto = maptoInstructorDto(i);
			
			instructorDtos.add(instructorDto);		
		}
		
		return instructorDtos;
	}
	
	@Override
	public InstructorDto getInstructorDtoById(int id )
	{
		
		Optional<Instructor> optionalinstructor = instructorRepo.findById(id);
		
		if(optionalinstructor.isEmpty())
		 return null;
		
		Instructor instructor = optionalinstructor.get();
		
	//	InstructorDto	instructorDto = maptoInstructorDto(instructor);
		
		return maptoInstructorDto(instructor);
		
	}

}
