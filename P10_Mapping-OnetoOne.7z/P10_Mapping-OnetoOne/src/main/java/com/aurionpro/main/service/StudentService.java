package com.aurionpro.main.service;



import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.RequestBody;

import com.aurionpro.main.entity.Address;
import com.aurionpro.main.entity.Student;

public interface StudentService {

	 Student addStudent(Student student);
	
	 Page<Student> getAllStudent(int pageNumber,int pageSize);
	 
	 Address findStudentAddress(int rollno);
	 
	 Student findStudent(int rollno);
	 
	 Student updateStudentAddress(int rollno,String buildingName,  String areaName, String city , int pincode);

	 Student updateStudentAddress2(int rollno,Address address);
}
