package com.aurionpro.main.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.aurionpro.main.dto.PageResponseDto;
import com.aurionpro.main.entity.Address;
import com.aurionpro.main.entity.Student;
import com.aurionpro.main.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentRepo;
	
	@Override
	public Student addStudent(Student student) {
			
		return studentRepo.save(student);
	}

	@Override
	public Page<Student> getAllStudent(int pageNumber, int pageSize) {
		
		 Pageable pageable= PageRequest.of(pageNumber, pageSize);
		 
		 Page page = studentRepo.findAll(pageable);
		 
		 PageResponseDto pageResponseDto = new PageResponseDto();
		 
		 pageResponseDto.setContent(page.getContent());
		 pageResponseDto.setPageNumber(page.getNumber());
		 pageResponseDto.setPageSize(page.getSize());
		 return studentRepo.findAll(pageable);
	}

	@Override
	public Address findStudentAddress(int rollno) {
		
		Optional<Student> student = studentRepo.findById(rollno);
		
		if(!student.isPresent())
			return null;
		
		 Student student1 =student.get();
		 Address address = student1.getAddressId();
		 
		return address;
	}

	@Override
	public Student findStudent(int rollno) {
		Optional<Student> student = studentRepo.findById(rollno);
		
		 Student student1 =student.get();
		 
		return student1;
	}

	@Override
	public Student updateStudentAddress(int rollno,String buildingName, String areaName, String city , int pincode) {
		// TODO Auto-generated method stub
		Student student = findStudent(rollno);
		
		Address newAddress = new Address(rollno,buildingName,areaName,city,pincode);
		
		student.setAddressId(newAddress);
		
		studentRepo.save(student).getAddressId();
		return student;
	}

	@Override
	public Student updateStudentAddress2(int rollno, Address address) {
		Student student =null;
		Optional<Student> student1 = studentRepo.findById(rollno);
		
		 if(!student1.isPresent())
			 return null;
		 
		 student = student1.get();
		Address newAddress = address;
		
		student.setAddressId(newAddress);
		
		studentRepo.save(student).getAddressId();
		
		return student;
	}
	
	
	
	

}
