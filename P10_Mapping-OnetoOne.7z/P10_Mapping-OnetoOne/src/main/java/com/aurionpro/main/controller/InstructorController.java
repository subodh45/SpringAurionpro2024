package com.aurionpro.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aurionpro.main.dto.InstructorDto;
import com.aurionpro.main.service.InstructorService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
@RequestMapping("/advancemappingapp")
public class InstructorController {

	@Autowired
	private InstructorService instructorService;
	
	@PostMapping("/instructors")
	public ResponseEntity<InstructorDto> addNewInstructorDto(@RequestBody InstructorDto instructorDto)
	{
		return ResponseEntity.ok(instructorService.addInstructor(instructorDto));
	}
	
	@GetMapping("/instructors")
	public ResponseEntity<List<InstructorDto>> getAllInstructorDto()
	{
		return ResponseEntity.ok(instructorService.getAllInstructor());
	}
	
	@GetMapping("/instructors/{id}")
	public ResponseEntity<InstructorDto> getInstructorDtobyId(@PathVariable int id)
	{
		return ResponseEntity.ok(instructorService.getInstructorDtoById(id));
	}
	
}
