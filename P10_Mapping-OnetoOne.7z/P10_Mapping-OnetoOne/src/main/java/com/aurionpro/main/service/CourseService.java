package com.aurionpro.main.service;

import java.util.List;

import com.aurionpro.main.dto.CourseDto;
import com.aurionpro.main.dto.InstructorDto;

public interface CourseService {

	CourseDto addNewCourse(CourseDto courseDto);
	
    List<CourseDto> getAllCourse();
	
	CourseDto getCourseDtoById(int id);
	
}
