package com.aurionpro.main.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.aurionpro.main.entity.Client;

public interface ClientService {

	void addClient(Client client);
	void updateClient(Client client);
	
	Page<Client> getAllClient(int pageSize,int pageNumber);
	
	Page<Client> getAllClientbycompanyName(String name ,int pageSize,int pageNumber);
}
