package com.aurionpro.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.aurionpro.main.entity.Employee;
import com.aurionpro.main.repository.EmployeeRepository;

@Service
public class EmployeeServiceimpl implements EmployeeService {

	
	@Autowired
	private EmployeeRepository employeeRepo;
	
	@Override
	public void addEmployee(Employee employee) {
		employeeRepo.save(employee);
		
	}

	@Override
	public void updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		employeeRepo.save(employee);
	}

	@Override
	public Page<Employee> getAllEmployee(int pageSize, int pageNumber) {
		Pageable pageable = PageRequest.of(pageNumber, pageSize);
		return employeeRepo.findAll(pageable);
		
	}

	@Override
	public Page<Employee> getAllEmployeebyfirstName(String name, int pageSize, int pageNumber) {
		Pageable pageable = PageRequest.of(pageNumber, pageSize);
		return employeeRepo.findByfirstName(name, pageable);
	}

}
