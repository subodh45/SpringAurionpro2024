package com.aurionpro.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.aurionpro.main.entity.Client;
import com.aurionpro.main.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService{

	@Autowired
	private ClientRepository clientRepo;
	
	@Override
	public void addClient(Client client) {
		
		clientRepo.save(client);
	}

	@Override
	public void updateClient(Client client) {
		
		clientRepo.save(client);
	}

	@Override
	public Page<Client> getAllClient(int pageSize,int pageNumber) {
		
		Pageable pageable = PageRequest.of(pageNumber, pageSize);
		return clientRepo.findAll(pageable);
	}

	@Override
	public Page<Client> getAllClientbycompanyName(String name, int pageSize, int pageNumber) {
		
		Pageable pageable = PageRequest.of(pageNumber, pageSize);
		return clientRepo.findBycompanyName(name, pageable);
	}

}
