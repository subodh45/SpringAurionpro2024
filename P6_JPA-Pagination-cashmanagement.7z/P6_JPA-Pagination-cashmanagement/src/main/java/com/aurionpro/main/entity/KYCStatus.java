package com.aurionpro.main.entity;

public enum KYCStatus {
    PENDING,PROCESSING,COMPLETED
}
