package com.aurionpro.main.service;

import org.springframework.data.domain.Page;

import com.aurionpro.main.entity.Employee;

public interface EmployeeService {

	void addEmployee(Employee employee);
	void updateEmployee(Employee employee);
	
	Page<Employee> getAllEmployee(int pageSize,int pageNumber);
	
	Page<Employee> getAllEmployeebyfirstName(String name ,int pageSize,int pageNumber);
	
}
