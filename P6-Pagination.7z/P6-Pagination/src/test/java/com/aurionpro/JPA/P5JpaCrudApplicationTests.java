package com.aurionpro.JPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P5JpaCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
