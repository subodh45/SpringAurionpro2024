package com.aurionpro.JPA.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.aurionpro.JPA.entity.Student;
import com.aurionpro.JPA.repository.StudentRepository;

@Service
public class StudentServiceimple implements StudentService {
  
	@Autowired
	private StudentRepository studentRepository;
	
	
//	@Override
//	public List<Student> getAllStudent() {
//		
//		return studentRepository.findAll();
//	}
//
//
//	@Override
//	public Optional<Student> getStudent(int rollno) {
//		
//		return studentRepository.findById(rollno);
//	}
//
//
//	
//	@Override
//	public void addStudent(Student student) {
//		
//		studentRepository.save(student);
//	}
//
//
//	@Override
//	public void updatestudent(Student student) {
//		
//		studentRepository.save(student);
//	}


//	@Override
//	public Student getStudentByName(String name) {
//		
//		return  studentRepository.findByName(name);
//	}

//
//	@Override
//	public List<Student> getAllStudentByName(String name) {
//		// TODO Auto-generated method stub
//		return null;
//	}

	
	public Page<Student> getAllStudentspage(String name ,int pageSize,int pageNumber)
	{
		Pageable pageable = PageRequest.of(pageNumber, pageSize);
		
		return studentRepository.findByname(name, pageable );
	}

	
	public Page<Student> getAllStudents(int pageSize,int pageNumber)
	{
		Pageable pageable = PageRequest.of(pageNumber, pageSize);
		
		return studentRepository.findAll(pageable);
	}

	

}
