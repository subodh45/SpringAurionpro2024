package com.aurionpro.JPA.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;

import com.aurionpro.JPA.entity.Student;

public interface StudentService {

//	List<Student> getAllStudent();
	
//	Optional<Student> getStudent(int rollno);
//	
//	Student getStudentByName(String name);
//	
//	void addStudent(Student student);
//	
//	void updatestudent(Student student);
	
//	List<Student> getAllStudentByName(String name,int pageSize,int pageNumber);
	
	Page<Student> getAllStudents(int pageSize,int pageNumber);
	
	Page<Student> getAllStudentspage(String name ,int pageSize,int pageNumber);
	
	
}
