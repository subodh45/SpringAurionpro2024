package com.aurionpro.JPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P5JpaCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(P5JpaCrudApplication.class, args);
	}

}
